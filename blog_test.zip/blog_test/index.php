<?php

header('Location: products/index.php');

