<?php

try {
	$pdo = new PDO('mysql:dbname=blog_text; host=localhost', 'root', '');
} catch (PDOException $e) {
	die($e->getMessage());
}