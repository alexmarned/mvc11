<?php 
include_once 'func.php';
include_once 'header.php';
include_once 'nav_bar.php';

foreach ($result as )
{
    
}
?>
        <form action="?id=<?=$value['id'] ?>" method="post">
        	<div class="form-group">
        		<input type="text" class="form-control" name="edit_name" value="<?=$result['name'] ?>" placeholder="Имя">
        	</div>
        	<div class="form-group">
        		<input type="text" class="form-control" name="edit_vendor_code" value="<?=$value['last_name'] ?>" placeholder="Фамилия">
        	</div>
        	<div class="form-group">
        		<input type="text" class="form-control" name="edit_price" value="<?=$value['pos'] ?>" placeholder="Должность">
        	</div>
            
            <div class="form-group">
        		<input type="text" class="form-control" name="edit_product_dimensions" value="<?=$value['pos'] ?>" placeholder="Должность">
        	</div>
            
            
            
        	<div class="modal-footer">
        		<button type="submit" name="edit-submit" class="btn btn-primary">Обновить</button>
        	</div>
        </form>	
    <?php
include_once 'footer.php';