<?php
include '../config.php';

$name = $_POST['name'] ?? '';
$vendor_code = $_POST['vendor_code'] ?? '';
$price = $_POST['price'] ?? '';
$product_dimensions = $_POST['product_dimensions'] ?? '';
$user_name = $_POST['user_name'] ?? '';

// Create
if (isset($_POST['submit'])) {
	$sql = ("INSERT INTO `products`(`name`, `vendor_code`, `price`, 'product_dimensions', 'user_name') VALUES(?,?,?,?,?)");
	$query = $pdo->prepare($sql);
	$query->execute([$name, $vendor_code, $price, $product_dimensions, $user_name]);
	$success = '<div class="alert alert-success alert-dismissible fade show" role="alert">
  <strong>Данные успешно отправлены!</strong> Вы можете закрыть это сообщение.
  <button type="button" class="close" data-dismiss="alert" aria-label="Close">
    <span aria-hidden="true">&times;</span>
  </button>
</div>';
	
}

// Read
$sql = $pdo->prepare("SELECT * FROM `products`");
$sql->execute();
$result = $sql->fetchAll();

// Update
$edit_name = $_POST['edit_name'] ?? '';
$edit_last_name = $_POST['edit_last_name'] ?? '';
$edit_pos = $_POST['edit_pos'] ?? '';
$get_id = $_GET['id'] ?? '';
if (isset($_POST['edit-submit'])) {
	$sqll = "UPDATE users SET name=?, last_name=?, pos=? WHERE id=?";
	$querys = $pdo->prepare($sqll);
	$querys->execute([$edit_name, $edit_last_name, $edit_pos, $get_id]);
	header('Location: '. $_SERVER['HTTP_REFERER']);
}

// DELETE
if (isset($_POST['delete_submit'])) {
	$sql = "DELETE FROM users WHERE id=?";
	$query = $pdo->prepare($sql);
	$query->execute([$get_id]);
	header('Location: '. $_SERVER['HTTP_REFERER']);
}
